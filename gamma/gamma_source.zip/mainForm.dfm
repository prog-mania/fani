object Form1: TForm1
  Left = 393
  Top = 406
  Width = 445
  Height = 224
  HorzScrollBar.Visible = False
  VertScrollBar.Visible = False
  Caption = #1040#1074#1090#1086#1084#1072#1090#1080#1095#1077#1089#1082#1072#1103' '#1088#1077#1075#1091#1083#1080#1088#1086#1074#1082#1072' '#1103#1088#1082#1086#1089#1090#1080' '
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = True
  OnCloseQuery = FormCloseQuery
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbConnect: TLabel
    Left = 128
    Top = 144
    Width = 130
    Height = 13
    Caption = #1053#1077#1090' '#1089#1086#1077#1076#1080#1085#1077#1085#1080#1103' '#1089' Arduino'
  end
  object Label1: TLabel
    Left = 37
    Top = 50
    Width = 42
    Height = 16
    Caption = #1058#1077#1084#1085#1086
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Microsoft Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 230
    Top = 50
    Width = 48
    Height = 16
    Caption = #1057#1074#1077#1090#1083#1086
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Microsoft Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 37
    Top = 16
    Width = 80
    Height = 19
    Caption = #1054#1089#1074#1077#1097#1077#1085#1080#1077
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label4: TLabel
    Left = 130
    Top = 16
    Width = 7
    Height = 19
    Caption = '?'
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 231
    Top = 16
    Width = 53
    Height = 19
    Caption = #1071#1088#1082#1086#1089#1090#1100
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 297
    Top = 16
    Width = 8
    Height = 19
    Caption = '0'
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label8: TLabel
    Left = 294
    Top = 50
    Width = 15
    Height = 16
    Caption = '-->'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label9: TLabel
    Left = 40
    Top = 99
    Width = 54
    Height = 14
    Caption = #1059#1089#1090#1072#1085#1086#1074#1082#1072
    Font.Charset = RUSSIAN_CHARSET
    Font.Color = clBlack
    Font.Height = -12
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object SpeedButton1: TSpeedButton
    Left = 37
    Top = 138
    Width = 81
    Height = 26
    Caption = 'Arduino'
    Layout = blGlyphBottom
    Spacing = 0
    OnClick = Button1Click
  end
  object Label10: TLabel
    Left = 185
    Top = 16
    Width = 19
    Height = 20
    Caption = '-->'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label7: TLabel
    Left = 96
    Top = 50
    Width = 15
    Height = 16
    Caption = '-->'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object TrackBar1: TTrackBar
    Left = 32
    Top = 66
    Width = 179
    Height = 30
    Max = 150
    Frequency = 10
    Position = 50
    TabOrder = 0
    TabStop = False
    TickMarks = tmBoth
    OnChange = TrackBar1Change
  end
  object TrackBar2: TTrackBar
    Left = 219
    Top = 66
    Width = 179
    Height = 30
    Max = 150
    Frequency = 10
    Position = 50
    TabOrder = 1
    TabStop = False
    TickMarks = tmBoth
    OnChange = TrackBar2Change
  end
end
