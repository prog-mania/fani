upx -9 --force gamma.exe
